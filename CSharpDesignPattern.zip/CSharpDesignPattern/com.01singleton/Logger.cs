﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpDesignPattern.com._01singleton
{
	public class Logger
	{
		private  Logger() { }
		private static Logger logger;

		public static Logger GetInstance() {
			if (logger == null) {
				logger = new Logger();
			
			}
			return logger;
		}
	}
}
